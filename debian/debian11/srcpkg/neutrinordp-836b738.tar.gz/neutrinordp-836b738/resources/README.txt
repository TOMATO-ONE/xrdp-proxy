
To create an image that is displayed as the NeutrinoRDP icon:

1) The image must be 256x256 pixels
2) Preferably have a transparent background
3) Must be PNG format
4) Filename must be FreeRDP_Icon_256px.png
5) run the following command

python ./conv_to_ewm_prop.py FreeRDP_Icon_256px.png FreeRDP_Icon_256px.h




