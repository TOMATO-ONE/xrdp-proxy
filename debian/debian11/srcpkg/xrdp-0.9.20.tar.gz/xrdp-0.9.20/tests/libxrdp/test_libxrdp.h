#ifndef TEST_LIBXRDP_H
#define TEST_LIBXRDP_H

#include <check.h>

Suite *make_suite_test_monitor_processing(void);

#endif /* TEST_LIBXRDP_H */