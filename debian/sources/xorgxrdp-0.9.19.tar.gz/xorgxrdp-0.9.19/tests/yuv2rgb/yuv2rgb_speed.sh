#! /bin/sh

./yuv2rgb_speed runtest
